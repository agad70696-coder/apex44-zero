from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import FrozenSet, Optional


class RelationStatus(str, Enum):
    CANDIDATE = "CANDIDATE"
    ACCEPTED = "ACCEPTED"
    BLOCKED = "BLOCKED"
    CONTESTED = "CONTESTED"
    UNSUPPORTED = "UNSUPPORTED"
    REJECTED = "REJECTED"


class PropagationPermission(str, Enum):
    ALLOW = "ALLOW"
    DENY = "DENY"


@dataclass(frozen=True)
class EvidenceAssertion:
    evidence_id: str
    validator_status: str
    confidence: float
    source: str
    source_version: Optional[str] = None
    extractor_version: Optional[str] = None

    @property
    def verified(self) -> bool:
        return self.validator_status == "VERIFIED"


@dataclass(frozen=True)
class RelationContract:
    relation_type: str
    domain: FrozenSet[str]
    range: FrozenSet[str]
    inverse: Optional[str] = None
    symmetric: bool = False
    transitive: bool = False
    propagation_policy: str = "DENY"

    def accepts(self, source_type: str, target_type: str) -> bool:
        return source_type in self.domain and target_type in self.range


@dataclass(frozen=True)
class RelationCandidate:
    relation_id: str
    source_entity: str
    source_type: str
    target_entity: str
    target_type: str
    relation_type: str
    evidence: tuple[EvidenceAssertion, ...] = field(default_factory=tuple)
    transformation_rule: Optional[str] = None
    contract: Optional[RelationContract] = None
    conflict_id: Optional[str] = None
    status: RelationStatus = RelationStatus.CANDIDATE


def validate_relation(candidate: RelationCandidate) -> RelationStatus:
    """Validate structure; confidence never substitutes for validity."""
    if candidate.conflict_id:
        return RelationStatus.CONTESTED
    if not candidate.evidence:
        return RelationStatus.UNSUPPORTED
    if not all(e.verified for e in candidate.evidence):
        return RelationStatus.BLOCKED
    if candidate.transformation_rule is None:
        return RelationStatus.UNSUPPORTED
    if candidate.contract is None:
        return RelationStatus.BLOCKED
    if not candidate.contract.accepts(candidate.source_type, candidate.target_type):
        return RelationStatus.BLOCKED
    return RelationStatus.ACCEPTED


def propagation_permission(
    candidate: RelationCandidate, status: Optional[RelationStatus] = None
) -> PropagationPermission:
    """Propagation is an explicit gate, not a consequence of confidence."""
    resolved = status or validate_relation(candidate)
    if resolved != RelationStatus.ACCEPTED:
        return PropagationPermission.DENY
    if candidate.contract is None or candidate.contract.propagation_policy != "ALLOW":
        return PropagationPermission.DENY
    return PropagationPermission.ALLOW

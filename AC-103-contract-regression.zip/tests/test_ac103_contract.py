import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from IRRE.relations.contract import (
    EvidenceAssertion,
    RelationCandidate,
    RelationContract,
    RelationStatus,
    PropagationPermission,
    propagation_permission,
    validate_relation,
)


def evidence(eid="E08", confidence=0.99):
    return EvidenceAssertion(eid, "VERIFIED", confidence, "quran-corpus", "v1", "morph-v1")


def contract(relation="syntactic_target", policy="DENY"):
    return RelationContract(
        relation,
        frozenset({"TokenOccurrence"}),
        frozenset({"PrepositionalPhrase"}),
        propagation_policy=policy,
    )


def candidate(**overrides):
    data = dict(
        relation_id="R1",
        source_entity="T1",
        source_type="TokenOccurrence",
        target_entity="PP1",
        target_type="PrepositionalPhrase",
        relation_type="syntactic_target",
        evidence=(evidence(),),
        transformation_rule="BI_TARGET_RULE",
        contract=contract(policy="ALLOW"),
    )
    data.update(overrides)
    return RelationCandidate(**data)


def test_positive_auditable_relation_is_accepted_and_can_propagate():
    r = candidate()
    assert validate_relation(r) == RelationStatus.ACCEPTED
    assert propagation_permission(r) == PropagationPermission.ALLOW


def test_evidence_without_rule_is_unsupported_not_valid():
    r = candidate(transformation_rule=None)
    assert validate_relation(r) == RelationStatus.UNSUPPORTED
    assert propagation_permission(r) == PropagationPermission.DENY


def test_high_confidence_does_not_override_invalid_contract():
    bad = RelationContract(
        "semantic_target", frozenset({"Root"}), frozenset({"Concept"}), propagation_policy="ALLOW"
    )
    r = candidate(contract=bad)
    assert r.evidence[0].confidence == 0.99
    assert validate_relation(r) == RelationStatus.BLOCKED
    assert propagation_permission(r) == PropagationPermission.DENY


def test_verified_lower_confidence_can_remain_structurally_valid():
    r = candidate(evidence=(evidence(confidence=0.72),))
    assert validate_relation(r) == RelationStatus.ACCEPTED


def test_contested_relation_is_contained():
    r = candidate(conflict_id="C1")
    assert validate_relation(r) == RelationStatus.CONTESTED
    assert propagation_permission(r) == PropagationPermission.DENY


def test_root_to_concept_is_blocked_without_matching_contract():
    r = candidate(
        source_entity="Root(وصي)",
        source_type="Root",
        target_entity="Concept(الحق)",
        target_type="Concept",
        relation_type="semantic_related",
        transformation_rule=None,
        contract=None,
    )
    assert validate_relation(r) == RelationStatus.UNSUPPORTED
    assert propagation_permission(r) == PropagationPermission.DENY


def test_morphology_does_not_become_semantics_without_rule():
    r = candidate(
        relation_type="RECIPROCAL_ACTION",
        transformation_rule=None,
        contract=None,
    )
    assert validate_relation(r) == RelationStatus.UNSUPPORTED


def test_propagation_policy_is_independent_from_structural_acceptance():
    r = candidate(contract=contract(policy="DENY"))
    assert validate_relation(r) == RelationStatus.ACCEPTED
    assert propagation_permission(r) == PropagationPermission.DENY


def test_confidence_is_not_added_across_evidence_units():
    r = candidate(evidence=(evidence("E08", .6), evidence("E09", .6)))
    assert validate_relation(r) == RelationStatus.ACCEPTED
    assert sum(e.confidence for e in r.evidence) == 1.2
    # Acceptance is structural; no additive confidence is implied by the gate.
